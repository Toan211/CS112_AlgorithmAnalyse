Trong file gồm có:
1. bản pdf báo cáo

2. thư mục source latex

3. thư mục source, trong đó:
   3.1.  Code nguồn
	3.1.1. Code BackTracking có thể in ra tất cả các subset mảng, tuy nhiên code Dynamic chỉ có thể in ra được 1 subset mảng

	3.1.3. Cách nhập dữ liêu:  
		3.1.3.1. nhập input mảng: 1(cách dòng)2(cách dòng)3...
		3.1.3.2. nhập tổng Sum  : 5

   3.2.  file excel chạy thực nghiệm

   3.3.  các file phát sinh input, output, trong đó:
   	3.3.1.  Code phát sinh input, output (chỉ xuất 1 mảng)

   	3.3.2.  file input mảng

	3.3.3.  Các file output cho từng thuật toán ứng với mỗi file input